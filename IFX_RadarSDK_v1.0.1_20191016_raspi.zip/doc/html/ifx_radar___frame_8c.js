var ifx_radar___frame_8c =
[
    [ "ifx_device_create_frame", "ifx_radar___frame_8c.html#a26abe6bb17201ae8bc68ee24985332ae", null ],
    [ "ifx_device_destroy_frame", "ifx_radar___frame_8c.html#ab86285552b075852dcb9fe7d87211188", null ]
];