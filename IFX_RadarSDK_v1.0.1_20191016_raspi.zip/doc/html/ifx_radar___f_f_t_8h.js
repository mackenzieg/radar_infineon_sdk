var ifx_radar___f_f_t_8h =
[
    [ "ifx_FFT_Handle_t", "ifx_radar___f_f_t_8h.html#a711a77e5436b9b33ba734394e1f8e902", null ],
    [ "ifx_FFT_Size_t", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881", [
      [ "FFT_SIZE_16", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881a6f7406541db6e5fca6a86161d32f0f30", null ],
      [ "FFT_SIZE_32", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881a1acd2d34c5e0793f6fa6546aa491f722", null ],
      [ "FFT_SIZE_64", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881a363570065bf56553f8aa7023d231bf74", null ],
      [ "FFT_SIZE_128", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881ad36030fd38b08b29b00c97ad6a28b0e4", null ],
      [ "FFT_SIZE_256", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881a8ce799b08facec81beab72293705f6f1", null ],
      [ "FFT_SIZE_512", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881af7bf734b0634851af3646c856dd27d48", null ],
      [ "FFT_SIZE_1024", "ifx_radar___f_f_t_8h.html#aade3f04f8e34e743939f9ad8e30dd881a3c474fe5e7474389b4e4da83153e187c", null ]
    ] ],
    [ "ifx_FFT_Type_t", "ifx_radar___f_f_t_8h.html#a50640235a580a81b42ceba51d9f36e7e", [
      [ "FFT_TYPE_R2C", "ifx_radar___f_f_t_8h.html#a50640235a580a81b42ceba51d9f36e7ea68d76fc8ce1495a44fc9c4de26c23afd", null ],
      [ "FFT_TYPE_C2C", "ifx_radar___f_f_t_8h.html#a50640235a580a81b42ceba51d9f36e7ea7f1316898480f69eca3b693ba2f6d5ce", null ]
    ] ],
    [ "ifx_fft_create", "ifx_radar___f_f_t_8h.html#a610083f0d8201c9de1c0fb683ac98fd9", null ],
    [ "ifx_fft_destroy", "ifx_radar___f_f_t_8h.html#a6ee78e1537e689c7506b9a4d69330ab8", null ],
    [ "ifx_fft_get_fft_size", "ifx_radar___f_f_t_8h.html#add1e1554f74fc5da1c882b59064a5d56", null ],
    [ "ifx_fft_get_fft_type", "ifx_radar___f_f_t_8h.html#a0bb5e824f7b44bd957254b98743d22ec", null ],
    [ "ifx_fft_get_zero_pad_length", "ifx_radar___f_f_t_8h.html#a5315d413e0b7fee00990f72d551a19e3", null ],
    [ "ifx_fft_run_c", "ifx_radar___f_f_t_8h.html#a6fc04d740dc0b6e90b6bb5387c5bc473", null ],
    [ "ifx_fft_run_r", "ifx_radar___f_f_t_8h.html#a0b29c13e155929a281e89a1a11b7716b", null ],
    [ "ifx_fft_shift_c", "ifx_radar___f_f_t_8h.html#aa5135f36cc4fe16c46104b055bc7e5c6", null ],
    [ "ifx_fft_shift_r", "ifx_radar___f_f_t_8h.html#ae146fd9e03522ce788acc6ab838e9388", null ]
];