var structifx___vector___c__t =
[
    [ "data", "structifx___vector___c__t.html#a5d67cface920506c9ac8dd0c944b4b6f", null ],
    [ "length", "structifx___vector___c__t.html#aebb70c2aab3407a9f05334c47131a43b", null ]
];