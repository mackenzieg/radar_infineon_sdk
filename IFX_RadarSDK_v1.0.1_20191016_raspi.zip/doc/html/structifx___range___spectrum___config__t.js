var structifx___range___spectrum___config__t =
[
    [ "chirp_bandwidth_khz", "structifx___range___spectrum___config__t.html#a50bee4ff851d220c61ddac9cad5982ea", null ],
    [ "fft_config", "structifx___range___spectrum___config__t.html#a89cfbdb1b8fa60d1f545e2ea194f9e16", null ],
    [ "num_of_chirps_per_frame", "structifx___range___spectrum___config__t.html#a35dae8ed7edb078bf0ba84867663c766", null ],
    [ "output_scale_type", "structifx___range___spectrum___config__t.html#ad53006cbbc67c14125c27731f59f98e5", null ],
    [ "spect_threshold", "structifx___range___spectrum___config__t.html#adb93ab255f33613617cad8875e760bc4", null ]
];