var ifx_radar___range_spectrum_8c =
[
    [ "ifx_Range_Spectrum_s", "structifx___range___spectrum__s.html", "structifx___range___spectrum__s" ],
    [ "CHECK_CALL_DESTROY_RETURN", "ifx_radar___range_spectrum_8c.html#aedc29842ab9feeef525b0eb2b7877a69", null ],
    [ "CLIPPING_VALUE", "ifx_radar___range_spectrum_8c.html#a550b1544733c642e2e37edb3f35fb805", null ],
    [ "GET_INDEX_OF_HIGHEST_ENERGY", "ifx_radar___range_spectrum_8c.html#a4444f15a4428cec833ffd08c682c897b", null ],
    [ "RANGE_SPEC", "ifx_radar___range_spectrum_8c.html#a0843f9f33f4c373b995b66700a89b988", null ],
    [ "get_index_of_highest_energy_c", "ifx_radar___range_spectrum_8c.html#afe5f4e8c263b82003a547599821645f8", null ],
    [ "get_index_of_highest_energy_r", "ifx_radar___range_spectrum_8c.html#abee463774c8382c610a4f9ef723953ef", null ],
    [ "ifx_range_spectrum_coherent_integration_run_c", "ifx_radar___range_spectrum_8c.html#aa36a40e3a2db15f2791c2f79e4393eae", null ],
    [ "ifx_range_spectrum_coherent_integration_run_r", "ifx_radar___range_spectrum_8c.html#a31dc9cf3742386dec838d12d5f4bee58", null ],
    [ "ifx_range_spectrum_create", "ifx_radar___range_spectrum_8c.html#a0f0b67190fc38ef13a2380e34498cc13", null ],
    [ "ifx_range_spectrum_destroy", "ifx_radar___range_spectrum_8c.html#a3f13af7e0d65ce3371b3adf48c0c0ca8", null ],
    [ "ifx_range_spectrum_get_fft_transformed_matrix", "ifx_radar___range_spectrum_8c.html#a1e6ec220110f4b915c6fa0b742592344", null ],
    [ "ifx_range_spectrum_get_mode", "ifx_radar___range_spectrum_8c.html#a5acb4a9e9c01f0b43696f7a0c111bf96", null ],
    [ "ifx_range_spectrum_get_output_scale_type", "ifx_radar___range_spectrum_8c.html#adebfc832a8a22e542bf9fb801044ad77", null ],
    [ "ifx_range_spectrum_get_range_axis_info", "ifx_radar___range_spectrum_8c.html#a98e31e3d37ff9fc21132bfdf7a528bd4", null ],
    [ "ifx_range_spectrum_get_single_chirp_mode_index", "ifx_radar___range_spectrum_8c.html#a6146c1479aa4cbed431b0011505dc057", null ],
    [ "ifx_range_spectrum_run_c", "ifx_radar___range_spectrum_8c.html#adca08d082b23eadaadac34a9afdf42c1", null ],
    [ "ifx_range_spectrum_run_r", "ifx_radar___range_spectrum_8c.html#afa1e8e01d5f6dc89eb4eba3539fe47c6", null ],
    [ "ifx_range_spectrum_set_mode", "ifx_radar___range_spectrum_8c.html#a684697b37e0086b637e3707e8742c448", null ],
    [ "ifx_range_spectrum_set_output_scale_type", "ifx_radar___range_spectrum_8c.html#a6bc749d4643c85a586745b98e5c99782", null ],
    [ "ifx_range_spectrum_set_single_chirp_mode_index", "ifx_radar___range_spectrum_8c.html#aeea7e755d10d4a8a1334858b092b6ed6", null ]
];