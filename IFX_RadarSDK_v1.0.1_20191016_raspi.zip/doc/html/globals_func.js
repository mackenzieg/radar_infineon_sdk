var globals_func =
[
    [ "b", "globals_func.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ]
];