var ifx_radar___log_8c =
[
    [ "IFX_LOG_TAG_DEBUG", "ifx_radar___log_8c.html#a5bf466ba0b035b58cc7dae0c24cdf1c7", null ],
    [ "IFX_LOG_TAG_ERROR", "ifx_radar___log_8c.html#a81ede3c088719f2a8b16910081b20326", null ],
    [ "IFX_LOG_TAG_INFO", "ifx_radar___log_8c.html#a2064f31a4b2305210887b140045ea27c", null ],
    [ "IFX_LOG_TAG_WARN", "ifx_radar___log_8c.html#acf724f96748ec3065573bb0438874941", null ],
    [ "get_severity_tag", "ifx_radar___log_8c.html#ac0c17c022c3c80712faaf8f397956788", null ],
    [ "ifx_log", "ifx_radar___log_8c.html#a2593a4bf94d3477d5869fdb7566fce5d", null ]
];