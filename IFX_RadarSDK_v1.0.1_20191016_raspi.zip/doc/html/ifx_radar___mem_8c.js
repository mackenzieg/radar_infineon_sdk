var ifx_radar___mem_8c =
[
    [ "ALIGNED_FREE", "ifx_radar___mem_8c.html#af731de9cc13bd4fef89fbddb7a7e5254", null ],
    [ "ALIGNED_MALLOC", "ifx_radar___mem_8c.html#a83b5d2f9ec5912749f0b90243969338a", null ],
    [ "TOTAL_MEM", "ifx_radar___mem_8c.html#a69c48f4fe50151ac0b9cd2a14417c5b7", null ],
    [ "TRACK_MEM", "ifx_radar___mem_8c.html#a390ba827427d8c91ffb41ca1b69e95bc", null ],
    [ "UNTRACK_MEM", "ifx_radar___mem_8c.html#aa8cc7a0ecdb9c826f35572e51dfdb9a8", null ],
    [ "ifx_mem_aligned_alloc", "ifx_radar___mem_8c.html#a7e7a09693e3e47510a771b356f25d29e", null ],
    [ "ifx_mem_aligned_free", "ifx_radar___mem_8c.html#a3ff07fb6789dadf1d89dc68bae5d8697", null ],
    [ "ifx_mem_alloc", "ifx_radar___mem_8c.html#aa9ecfd0f473eb3e279e3a1fac86f47f8", null ],
    [ "ifx_mem_calloc", "ifx_radar___mem_8c.html#af6ddd82d94ade65fc5e7bd3cd3618c8a", null ],
    [ "ifx_mem_free", "ifx_radar___mem_8c.html#a97222be1e319035121a5694f629de8d9", null ],
    [ "ifx_mem_get_total_alloc_size", "ifx_radar___mem_8c.html#a077659f1e7b286bb9ebcfad127c6d130", null ]
];