var structifx___frame__t =
[
    [ "num_rx", "structifx___frame__t.html#a3e801586835019ce481dbae9ea5d97b1", null ],
    [ "rx_data", "structifx___frame__t.html#ac9c179eab19f7f2d2946ed612dafd311", null ]
];