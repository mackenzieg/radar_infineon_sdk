var structifx___f_f_t__s =
[
    [ "fft_input_len", "structifx___f_f_t__s.html#a30f3b4337cdf6c333cb650599a3eaa63", null ],
    [ "fft_size", "structifx___f_f_t__s.html#a01dcb5abf4eaab7937387e6021ba9de6", null ],
    [ "fft_type", "structifx___f_f_t__s.html#a5e55069d1b92a17568e7095593121b5b", null ],
    [ "zero_pad_fft_inp_c", "structifx___f_f_t__s.html#ae3a3010237885350f6c67f0a6a6dfbfd", null ],
    [ "zero_pad_fft_inp_r", "structifx___f_f_t__s.html#ae6a218d53e27e1898e004cf5ad9a7275", null ]
];