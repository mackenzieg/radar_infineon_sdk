var structifx___matrix___c__t =
[
    [ "columns", "structifx___matrix___c__t.html#a56664eb80ec4f50e9fd0419e2eb335ca", null ],
    [ "data", "structifx___matrix___c__t.html#a5d67cface920506c9ac8dd0c944b4b6f", null ],
    [ "rows", "structifx___matrix___c__t.html#a11fd148437f8e38e54464cd7ec795c0e", null ]
];