var structifx___peak___search__s =
[
    [ "max_num_peaks", "structifx___peak___search__s.html#a19b63bf143f0010620bc17048364455c", null ],
    [ "peak_count", "structifx___peak___search__s.html#a5756f81bbde9d2af16889cc6302f8656", null ],
    [ "peak_idx", "structifx___peak___search__s.html#a47f323e8270e7a4f4380ca8418af0e0b", null ],
    [ "peak_val", "structifx___peak___search__s.html#adf20a2c5f94a6e3309333f163a6e7676", null ],
    [ "search_zone_end", "structifx___peak___search__s.html#ab031779afe0bb8dc14a2af6354e24aa7", null ],
    [ "search_zone_start", "structifx___peak___search__s.html#a086a604d01bf621e310a0f62a784fe76", null ],
    [ "threshold_factor", "structifx___peak___search__s.html#ad3758d5515690877e2250ef192eef210", null ],
    [ "threshold_offset", "structifx___peak___search__s.html#aa355556241f4f20ce4fbb5f4c2789a58", null ],
    [ "value_per_bin", "structifx___peak___search__s.html#aade6e9e5790ccd07cc586905c4749200", null ]
];