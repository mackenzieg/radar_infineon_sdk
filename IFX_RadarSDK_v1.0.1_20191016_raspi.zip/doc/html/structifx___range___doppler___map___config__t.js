var structifx___range___doppler___map___config__t =
[
    [ "center_frequency_khz", "structifx___range___doppler___map___config__t.html#a761e2c3209f2b192fb62f2e1041a1c3f", null ],
    [ "chirp_bandwidth_khz", "structifx___range___doppler___map___config__t.html#a9241c76520dbf2259592f47696f41713", null ],
    [ "chirp_repetition_time_sec", "structifx___range___doppler___map___config__t.html#a72d1b9f9b6b0a398f7dba2b8b197ac47", null ],
    [ "doppler_fft_config", "structifx___range___doppler___map___config__t.html#ad0a2430ab86a98a15b256f9133ee2f81", null ],
    [ "output_scale_type", "structifx___range___doppler___map___config__t.html#ad53006cbbc67c14125c27731f59f98e5", null ],
    [ "range_fft_config", "structifx___range___doppler___map___config__t.html#abc9d80b6665542798f3d4e756d4f4dad", null ],
    [ "spect_threshold", "structifx___range___doppler___map___config__t.html#adb93ab255f33613617cad8875e760bc4", null ]
];