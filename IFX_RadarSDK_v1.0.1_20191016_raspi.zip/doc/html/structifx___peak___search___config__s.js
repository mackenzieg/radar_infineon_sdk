var structifx___peak___search___config__s =
[
    [ "max_num_peaks", "structifx___peak___search___config__s.html#a19b63bf143f0010620bc17048364455c", null ],
    [ "search_zone_end", "structifx___peak___search___config__s.html#ab031779afe0bb8dc14a2af6354e24aa7", null ],
    [ "search_zone_start", "structifx___peak___search___config__s.html#a086a604d01bf621e310a0f62a784fe76", null ],
    [ "threshold_factor", "structifx___peak___search___config__s.html#ad3758d5515690877e2250ef192eef210", null ],
    [ "threshold_offset", "structifx___peak___search___config__s.html#aa355556241f4f20ce4fbb5f4c2789a58", null ],
    [ "value_per_bin", "structifx___peak___search___config__s.html#aade6e9e5790ccd07cc586905c4749200", null ]
];