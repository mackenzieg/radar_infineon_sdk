var ifx_radar___device_control_8h =
[
    [ "ifx_Device_Handle_t", "ifx_radar___device_control_8h.html#a80be69680fe103dbff5d0b32cf1832b7", null ],
    [ "ifx_device_create", "ifx_radar___device_control_8h.html#a0306e7baec735f8760cc9f590d35159a", null ],
    [ "ifx_device_create_dummy", "ifx_radar___device_control_8h.html#a6e063b91c66c5feb67886ca67c89c42c", null ],
    [ "ifx_device_create_frame_from_device_handle", "ifx_radar___device_control_8h.html#ae23be33710d02629f456c2e410df5db5", null ],
    [ "ifx_device_destroy", "ifx_radar___device_control_8h.html#a82d1342312f8a699a8238a9ea6210f3d", null ],
    [ "ifx_device_destroy_dummy", "ifx_radar___device_control_8h.html#adaf19ecadb8ab69ae49d88963a912bf2", null ],
    [ "ifx_device_get_next_frame", "ifx_radar___device_control_8h.html#a8fa413b6258e787c577609dc02fcc230", null ]
];