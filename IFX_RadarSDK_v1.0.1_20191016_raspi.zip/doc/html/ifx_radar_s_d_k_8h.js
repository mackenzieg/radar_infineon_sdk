var ifx_radar_s_d_k_8h =
[
    [ "IFX_RADAR_SDK_VERSION_MAJOR", "ifx_radar_s_d_k_8h.html#a82d9b5268b9c9b1e36dea83af46640a5", null ],
    [ "IFX_RADAR_SDK_VERSION_MINOR", "ifx_radar_s_d_k_8h.html#a720d6cfda914c41dddaeb9e703d7e8cb", null ],
    [ "IFX_RADAR_SDK_VERSION_PATCH", "ifx_radar_s_d_k_8h.html#a00ed6f98b853ba2fbe7711d86c378cc3", null ],
    [ "ifx_radar_sdk_get_version_string", "ifx_radar_s_d_k_8h.html#a7269c6cde2ac9828adb915a781cae762", null ]
];