var ifx_radar___window_8h =
[
    [ "ifx_Window_Config_t", "structifx___window___config__t.html", "structifx___window___config__t" ],
    [ "ifx_Window_Type_t", "ifx_radar___window_8h.html#a4104d5848615f2111db1f3eaca27fd68", [
      [ "WINDOW_HAMM", "ifx_radar___window_8h.html#a4104d5848615f2111db1f3eaca27fd68a2b43c11a6b05836f49be7bad62bba7dd", null ],
      [ "WINDOW_HANN", "ifx_radar___window_8h.html#a4104d5848615f2111db1f3eaca27fd68af8fe57b782cddb6decfe9a68d34494ea", null ],
      [ "WINDOW_BLACKMANHARRIS", "ifx_radar___window_8h.html#a4104d5848615f2111db1f3eaca27fd68af12106ba85821f44a170b522403c74bc", null ],
      [ "WINDOW_CHEBYSHEV", "ifx_radar___window_8h.html#a4104d5848615f2111db1f3eaca27fd68a8bc4c877ad51e7805470bff4dd8e289a", null ]
    ] ],
    [ "ifx_window_init", "ifx_radar___window_8h.html#a086cede82256b3d60b2ab7160607cc69", null ]
];