var ifx_radar___device_config_8h =
[
    [ "ifx_Device_Config_t", "structifx___device___config__t.html", "structifx___device___config__t" ],
    [ "DEVICE_RX_ANTENNA1", "ifx_radar___device_config_8h.html#a1a4ac13543edd227e06ede17503deba8", null ],
    [ "DEVICE_RX_ANTENNA2", "ifx_radar___device_config_8h.html#a72146c02b397feb8ffb3a7b9cb140e64", null ],
    [ "DEVICE_RX_ANTENNA3", "ifx_radar___device_config_8h.html#aa8121bde1d57a9d25247e62b29eafbd1", null ]
];