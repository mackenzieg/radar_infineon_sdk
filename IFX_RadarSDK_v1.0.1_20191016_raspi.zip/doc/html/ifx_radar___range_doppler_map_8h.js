var ifx_radar___range_doppler_map_8h =
[
    [ "ifx_Range_Doppler_Map_Config_t", "structifx___range___doppler___map___config__t.html", "structifx___range___doppler___map___config__t" ],
    [ "ifx_Range_Doppler_Map_Handle_t", "ifx_radar___range_doppler_map_8h.html#ac298224dee786980c10a8e8fc3956f45", null ],
    [ "ifx_range_doppler_map_create", "ifx_radar___range_doppler_map_8h.html#a01b00bbc2d149c97fd0c4768673b4625", null ],
    [ "ifx_range_doppler_map_destroy", "ifx_radar___range_doppler_map_8h.html#a29eb48bc58fb074aed8a9aaeb447b22e", null ],
    [ "ifx_range_doppler_map_get_output_scale_type", "ifx_radar___range_doppler_map_8h.html#acf3fc55a827a2e00c8e5bb53c1c41db1", null ],
    [ "ifx_range_doppler_map_get_range_axis_info", "ifx_radar___range_doppler_map_8h.html#ac8a22303d0fb30e0f81e87d18fda069f", null ],
    [ "ifx_range_doppler_map_get_speed_axis_info", "ifx_radar___range_doppler_map_8h.html#a1be43b9a4b70520370dc13ed97783c60", null ],
    [ "ifx_range_doppler_map_get_threshold", "ifx_radar___range_doppler_map_8h.html#ac90a3c9586b42076d40bd515a4bca923", null ],
    [ "ifx_range_doppler_map_run_c", "ifx_radar___range_doppler_map_8h.html#a13339a7e33219d5f5e0f761715d90a89", null ],
    [ "ifx_range_doppler_map_run_r", "ifx_radar___range_doppler_map_8h.html#a622367993cc1cf9cb5c751a270ade259", null ],
    [ "ifx_range_doppler_map_set_output_scale_type", "ifx_radar___range_doppler_map_8h.html#a2f707f2218e03f743627e94bd9c79441", null ],
    [ "ifx_range_doppler_map_set_threshold", "ifx_radar___range_doppler_map_8h.html#ac4fc4ab9478027deaa69119cddc8e2cd", null ],
    [ "ifx_range_doppler_map_update_doppler_window", "ifx_radar___range_doppler_map_8h.html#acf98b83fbb1554e0e70870bde2f608d9", null ],
    [ "ifx_range_doppler_map_update_range_window", "ifx_radar___range_doppler_map_8h.html#ade9091f8983c426237290a5e9293690c", null ]
];