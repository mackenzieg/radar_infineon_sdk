var structifx___vector___r__t =
[
    [ "data", "structifx___vector___r__t.html#a1704d21cdbdec040155d19632223043d", null ],
    [ "length", "structifx___vector___r__t.html#aebb70c2aab3407a9f05334c47131a43b", null ]
];