var dir_4aef5d9bdcacc80aaeaf2000aebe9a3a =
[
    [ "ifxRadar_Complex.h", "ifx_radar___complex_8h.html", "ifx_radar___complex_8h" ],
    [ "ifxRadar_DeviceConfig.h", "ifx_radar___device_config_8h.html", "ifx_radar___device_config_8h" ],
    [ "ifxRadar_DeviceControl.h", "ifx_radar___device_control_8h.html", "ifx_radar___device_control_8h" ],
    [ "ifxRadar_Error.h", "ifx_radar___error_8h.html", "ifx_radar___error_8h" ],
    [ "ifxRadar_FFT.h", "ifx_radar___f_f_t_8h.html", "ifx_radar___f_f_t_8h" ],
    [ "ifxRadar_Frame.h", "ifx_radar___frame_8h.html", "ifx_radar___frame_8h" ],
    [ "ifxRadar_Internal.h", "ifx_radar___internal_8h.html", "ifx_radar___internal_8h" ],
    [ "ifxRadar_Log.h", "ifx_radar___log_8h.html", "ifx_radar___log_8h" ],
    [ "ifxRadar_Math.h", "ifx_radar___math_8h.html", "ifx_radar___math_8h" ],
    [ "ifxRadar_Matrix.h", "ifx_radar___matrix_8h.html", "ifx_radar___matrix_8h" ],
    [ "ifxRadar_Mem.h", "ifx_radar___mem_8h.html", "ifx_radar___mem_8h" ],
    [ "ifxRadar_MTI.h", "ifx_radar___m_t_i_8h.html", "ifx_radar___m_t_i_8h" ],
    [ "ifxRadar_PeakSearch.h", "ifx_radar___peak_search_8h.html", "ifx_radar___peak_search_8h" ],
    [ "ifxRadar_PreprocessedFFT.h", "ifx_radar___preprocessed_f_f_t_8h.html", "ifx_radar___preprocessed_f_f_t_8h" ],
    [ "ifxRadar_RangeDopplerMap.h", "ifx_radar___range_doppler_map_8h.html", "ifx_radar___range_doppler_map_8h" ],
    [ "ifxRadar_RangeSpectrum.h", "ifx_radar___range_spectrum_8h.html", "ifx_radar___range_spectrum_8h" ],
    [ "ifxRadar_Types.h", "ifx_radar___types_8h.html", "ifx_radar___types_8h" ],
    [ "ifxRadar_Vector.h", "ifx_radar___vector_8h.html", "ifx_radar___vector_8h" ],
    [ "ifxRadar_Window.h", "ifx_radar___window_8h.html", "ifx_radar___window_8h" ],
    [ "ifxRadarSDK.h", "ifx_radar_s_d_k_8h.html", "ifx_radar_s_d_k_8h" ]
];