var structifx___device___config__t =
[
    [ "adc_samplerate_hz", "structifx___device___config__t.html#a87c99bbc1135c0e9634faa99279d5849", null ],
    [ "bgt_tx_power", "structifx___device___config__t.html#a03c255c988ba4ae82d92bf67249ea2cd", null ],
    [ "chirp_to_chirp_time_100ps", "structifx___device___config__t.html#a70e3c1e1c9b0f1545240e3594990194b", null ],
    [ "frame_end_delay_100ps", "structifx___device___config__t.html#ababc8778a4fb91ed74e9289ccf0a10d4", null ],
    [ "frame_period_us", "structifx___device___config__t.html#a8a0a0bcf21f5099b0e61a1100ed0a517", null ],
    [ "if_gain_dB", "structifx___device___config__t.html#ae929f2c9a77c488243f6498f469be93c", null ],
    [ "lower_frequency_kHz", "structifx___device___config__t.html#abba734dd3fb4ceb405a80efe90811236", null ],
    [ "num_chirps_per_frame", "structifx___device___config__t.html#abfc841b29eafa76af320b80e2431abbb", null ],
    [ "num_samples_per_chirp", "structifx___device___config__t.html#ab18a660da006a93d818beab75e58c85e", null ],
    [ "rx_antenna_mask", "structifx___device___config__t.html#af283e9b1ea00cc2669ac6371095f9907", null ],
    [ "shape_end_delay_100ps", "structifx___device___config__t.html#a376ae61e8f99069802efa14489f418aa", null ],
    [ "upper_frequency_kHz", "structifx___device___config__t.html#a095b020d2ada8123b11e9f5ac17547ba", null ]
];