var ifx_radar___m_t_i_8h =
[
    [ "ifx_MTI_Handle_t", "ifx_radar___m_t_i_8h.html#a59b8322bac73755541120a5f1ecf2f53", null ],
    [ "ifx_mti_create", "ifx_radar___m_t_i_8h.html#a8358788d2f8dda83e2a8286cedc87f39", null ],
    [ "ifx_mti_destroy", "ifx_radar___m_t_i_8h.html#afc95b8bd528f27878195c1ec6c535f91", null ],
    [ "ifx_mti_run", "ifx_radar___m_t_i_8h.html#a784aea5642c5ed8f1be09ecb77b2ab6d", null ]
];