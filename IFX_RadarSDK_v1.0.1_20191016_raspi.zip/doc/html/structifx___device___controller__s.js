var structifx___device___controller__s =
[
    [ "device_config", "structifx___device___controller__s.html#a2d8f0868e06f68fe4d2304399485afaa", null ],
    [ "endpoint_base", "structifx___device___controller__s.html#a1e46ef29ef076fb2bf750665a7d5e21d", null ],
    [ "endpoint_bgt60trxx", "structifx___device___controller__s.html#abd0a36dd914eff4dbcf68b98d5b00104", null ],
    [ "endpoint_bgt6x", "structifx___device___controller__s.html#a451796903b21d58fb862f9c132d278c1", null ],
    [ "endpoint_fmcw", "structifx___device___controller__s.html#a0e44a83ff94bc84ae2efc8cdf80aeeee", null ],
    [ "is_triggered", "structifx___device___controller__s.html#ae6f09c56cf4573bdcde43a5b8547ba94", null ],
    [ "num_antennas", "structifx___device___controller__s.html#a7ada64805ebdd11a60f06be2494ab90a", null ],
    [ "protocol_handle", "structifx___device___controller__s.html#a82c95089330af2c65104f8bb26c6f1bc", null ]
];