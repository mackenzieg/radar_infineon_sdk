var structifx___window___config__t =
[
    [ "at_dB", "structifx___window___config__t.html#ac40eb9bf21e8114b41a81ac85aff1f4c", null ],
    [ "size", "structifx___window___config__t.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "type", "structifx___window___config__t.html#a01a3f8194c4c8507f7f65d4cb9c25697", null ]
];