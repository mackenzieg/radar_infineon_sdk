var searchData=
[
  ['data',['data',['../structifx___complex__s.html#a534748ee20ea51d3201a1d3ef34574d3',1,'ifx_Complex_s::data()'],['../structifx___matrix___r__t.html#a1704d21cdbdec040155d19632223043d',1,'ifx_Matrix_R_t::data()'],['../structifx___matrix___c__t.html#a5d67cface920506c9ac8dd0c944b4b6f',1,'ifx_Matrix_C_t::data()'],['../structifx___vector___r__t.html#a1704d21cdbdec040155d19632223043d',1,'ifx_Vector_R_t::data()'],['../structifx___vector___c__t.html#a5d67cface920506c9ac8dd0c944b4b6f',1,'ifx_Vector_C_t::data()']]],
  ['delimiter',['DELIMITER',['../ifx_radar___version_8c.html#a23195218eef2cf21e2beae685a041783',1,'ifxRadar_Version.c']]],
  ['device_5fconfig',['device_config',['../structifx___device___controller__s.html#a2d8f0868e06f68fe4d2304399485afaa',1,'ifx_Device_Controller_s']]],
  ['device_5frx_5fantenna1',['DEVICE_RX_ANTENNA1',['../ifx_radar___device_config_8h.html#a1a4ac13543edd227e06ede17503deba8',1,'ifxRadar_DeviceConfig.h']]],
  ['device_5frx_5fantenna2',['DEVICE_RX_ANTENNA2',['../ifx_radar___device_config_8h.html#a72146c02b397feb8ffb3a7b9cb140e64',1,'ifxRadar_DeviceConfig.h']]],
  ['device_5frx_5fantenna3',['DEVICE_RX_ANTENNA3',['../ifx_radar___device_config_8h.html#aa8121bde1d57a9d25247e62b29eafbd1',1,'ifxRadar_DeviceConfig.h']]],
  ['doppler_5ffft_5fconfig',['doppler_fft_config',['../structifx___range___doppler___map___config__t.html#ad0a2430ab86a98a15b256f9133ee2f81',1,'ifx_Range_Doppler_Map_Config_t']]],
  ['doppler_5ffft_5fresult',['doppler_fft_result',['../structifx___range___doppler___map__s.html#a9d78d67f5d4b806934598e5ffd8d1e5a',1,'ifx_Range_Doppler_Map_s']]],
  ['doppler_5fpreprocessed_5ffft_5fhandle',['doppler_preprocessed_fft_handle',['../structifx___range___doppler___map__s.html#a3b516753febd77c9635e9389c52af611',1,'ifx_Range_Doppler_Map_s']]],
  ['draft_5fdevice_5faccess_5flayer_5fapi_5fdesign_5fdoxy_2eh',['DRAFT_device_access_layer_api_design_doxy.h',['../../../../../radar_transceiver/build/doc_html/html/_d_r_a_f_t__device__access__layer__api__design__doxy_8h.html',1,'']]],
  ['draft_5fdevice_5faccess_5flayer_5fdoxy_2eh',['DRAFT_device_access_layer_doxy.h',['../../../../../radar_transceiver/build/doc_html/html/_d_r_a_f_t__device__access__layer__doxy_8h.html',1,'']]],
  ['draft_5fdriver_5fdoxy_2eh',['DRAFT_driver_doxy.h',['../../../../../radar_transceiver/build/doc_html/html/_d_r_a_f_t__driver__doxy_8h.html',1,'']]],
  ['draft_5fsystem_5fsetup_5fdoxy_2eh',['DRAFT_system_setup_doxy.h',['../../../../../radar_transceiver/build/doc_html/html/_d_r_a_f_t__system__setup__doxy_8h.html',1,'']]],
  ['dummy_2ec',['dummy.c',['../../../../../radar_transceiver/build/doc_html/html/dummy_8c.html',1,'']]],
  ['draft_20pages',['Draft Pages',['../../../../../radar_transceiver/build/doc_html/html/pg_tcal_draft_pages.html',1,'']]],
  ['device_20access_20layer',['Device Access Layer',['../../../../../radar_transceiver/build/doc_html/html/spg_radarsdk_device_access_layer.html',1,'']]],
  ['device_20access_20layer_20api_20design',['Device Access Layer API Design',['../../../../../radar_transceiver/build/doc_html/html/spg_radarsdk_device_access_layer_api_design.html',1,'']]]
];
