var searchData=
[
  ['untrack_5fmem',['UNTRACK_MEM',['../ifx_radar___mem_8c.html#aa8cc7a0ecdb9c826f35572e51dfdb9a8',1,'ifxRadar_Mem.c']]],
  ['upper_5ffrequency_5fkhz',['upper_frequency_kHz',['../structifx___device___config__t.html#a095b020d2ada8123b11e9f5ac17547ba',1,'ifx_Device_Config_t']]]
];
