var searchData=
[
  ['if_5fgain_5fdb',['if_gain_dB',['../structifx___device___config__t.html#ae929f2c9a77c488243f6498f469be93c',1,'ifx_Device_Config_t']]],
  ['index',['index',['../structifx___peak___search___result__t.html#ae9387c181eeb9ccfe699ee7446123b99',1,'ifx_Peak_Search_Result_t']]],
  ['input_5fsampling_5ffreq_5fkhz',['input_sampling_freq_khz',['../structifx___preprocessed___f_f_t___config__t.html#af6fe97ce106debf4dc6ca76191f6ea2f',1,'ifx_Preprocessed_FFT_Config_t']]],
  ['is_5fnormalized_5fwindow',['is_normalized_window',['../structifx___preprocessed___f_f_t___config__t.html#ad213557be7b913986213761ba430b8f8',1,'ifx_Preprocessed_FFT_Config_t']]],
  ['is_5ftriggered',['is_triggered',['../structifx___device___controller__s.html#ae6f09c56cf4573bdcde43a5b8547ba94',1,'ifx_Device_Controller_s']]]
];
