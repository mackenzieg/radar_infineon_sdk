var searchData=
[
  ['get_5findex_5fof_5fhighest_5fenergy_5fc',['get_index_of_highest_energy_c',['../ifx_radar___range_spectrum_8c.html#afe5f4e8c263b82003a547599821645f8',1,'ifxRadar_RangeSpectrum.c']]],
  ['get_5findex_5fof_5fhighest_5fenergy_5fr',['get_index_of_highest_energy_r',['../ifx_radar___range_spectrum_8c.html#abee463774c8382c610a4f9ef723953ef',1,'ifxRadar_RangeSpectrum.c']]],
  ['get_5fseverity_5ftag',['get_severity_tag',['../ifx_radar___log_8c.html#ac0c17c022c3c80712faaf8f397956788',1,'ifxRadar_Log.c']]],
  ['get_5fthreshold',['get_threshold',['../ifx_radar___peak_search_8c.html#a77ccbfb0ed8d3caa1ae6dc5c3375bbdf',1,'ifxRadar_PeakSearch.c']]]
];
