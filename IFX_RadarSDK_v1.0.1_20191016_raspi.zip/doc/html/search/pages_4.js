var searchData=
[
  ['software_20stack',['Software Stack',['../pg_radarsdk.html',1,'']]],
  ['system_20setup',['System Setup',['../../../../../radar_transceiver/build/doc_html/html/pg_radarsdk_sys.html',1,'']]]
];
