var searchData=
[
  ['bgt_5ftx_5fpower',['bgt_tx_power',['../structifx___device___config__t.html#a03c255c988ba4ae82d92bf67249ea2cd',1,'ifx_Device_Config_t']]]
];
