var searchData=
[
  ['ifx_5fcomplex_5ft',['ifx_Complex_t',['../ifx_radar___complex_8h.html#a00401cf90b026f0c69d9bcbafd68aa9e',1,'ifxRadar_Complex.h']]],
  ['ifx_5fdevice_5fframe_5fstate_5ft',['ifx_Device_Frame_State_t',['../ifx_radar___device_control_8c.html#ab957e7d0276dd8af2c7bf31d35933f56',1,'ifxRadar_DeviceControl.c']]],
  ['ifx_5fdevice_5fhandle_5ft',['ifx_Device_Handle_t',['../ifx_radar___device_control_8h.html#a80be69680fe103dbff5d0b32cf1832b7',1,'ifxRadar_DeviceControl.h']]],
  ['ifx_5ferror_5ft',['ifx_Error_t',['../ifx_radar___error_8h.html#abf537e9520d6ac69a31fd976998f38f5',1,'ifxRadar_Error.h']]],
  ['ifx_5ffft_5fhandle_5ft',['ifx_FFT_Handle_t',['../ifx_radar___f_f_t_8h.html#a711a77e5436b9b33ba734394e1f8e902',1,'ifxRadar_FFT.h']]],
  ['ifx_5ffloat_5ft',['ifx_Float_t',['../ifx_radar___types_8h.html#a39079719d81fd7bcf3cd5113a6dbe905',1,'ifxRadar_Types.h']]],
  ['ifx_5fmti_5fhandle_5ft',['ifx_MTI_Handle_t',['../ifx_radar___m_t_i_8h.html#a59b8322bac73755541120a5f1ecf2f53',1,'ifxRadar_MTI.h']]],
  ['ifx_5fpeak_5fsearch_5fconfig_5ft',['ifx_Peak_Search_Config_t',['../ifx_radar___peak_search_8h.html#ad26115b9e24b00d0de61c23d51fb01f5',1,'ifxRadar_PeakSearch.h']]],
  ['ifx_5fpeak_5fsearch_5fhandle_5ft',['ifx_Peak_Search_Handle_t',['../ifx_radar___peak_search_8h.html#a2a1939158e22f4c3e5863f1d9714533f',1,'ifxRadar_PeakSearch.h']]],
  ['ifx_5fpolar_5ft',['ifx_Polar_t',['../ifx_radar___types_8h.html#a038d967a9d25c23b4aa2b3a44ad130f5',1,'ifxRadar_Types.h']]],
  ['ifx_5fpreprocessed_5ffft_5fhandle_5ft',['ifx_Preprocessed_FFT_Handle_t',['../ifx_radar___preprocessed_f_f_t_8h.html#a06820f083dbf2d16af4418c6124025f1',1,'ifxRadar_PreprocessedFFT.h']]],
  ['ifx_5frange_5fdoppler_5fmap_5fhandle_5ft',['ifx_Range_Doppler_Map_Handle_t',['../ifx_radar___range_doppler_map_8h.html#ac298224dee786980c10a8e8fc3956f45',1,'ifxRadar_RangeDopplerMap.h']]],
  ['ifx_5frange_5fspectrum_5fhandle_5ft',['ifx_Range_Spectrum_Handle_t',['../ifx_radar___range_spectrum_8h.html#acc6eb14fd03fe95b368884cef34ee013',1,'ifxRadar_RangeSpectrum.h']]]
];
