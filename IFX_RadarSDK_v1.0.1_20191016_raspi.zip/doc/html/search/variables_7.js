var searchData=
[
  ['length',['length',['../structifx___vector___r__t.html#aebb70c2aab3407a9f05334c47131a43b',1,'ifx_Vector_R_t::length()'],['../structifx___vector___c__t.html#aebb70c2aab3407a9f05334c47131a43b',1,'ifx_Vector_C_t::length()']]],
  ['lower_5ffrequency_5fkhz',['lower_frequency_kHz',['../structifx___device___config__t.html#abba734dd3fb4ceb405a80efe90811236',1,'ifx_Device_Config_t']]]
];
