var searchData=
[
  ['matrix_5fclone',['MATRIX_CLONE',['../ifx_radar___matrix_8c.html#a51743f0a1368d7cc9a0800fdd9215aed',1,'ifxRadar_Matrix.c']]],
  ['matrix_5fcopy',['MATRIX_COPY',['../ifx_radar___matrix_8c.html#af9267329964671ee9ac24c0bda60c93d',1,'ifxRadar_Matrix.c']]],
  ['matrix_5fget_5felement',['MATRIX_GET_ELEMENT',['../ifx_radar___matrix_8c.html#a8aaaff496c595725e77638928862c87c',1,'ifxRadar_Matrix.c']]],
  ['matrix_5fis_5fdim_5fsame',['MATRIX_IS_DIM_SAME',['../ifx_radar___matrix_8c.html#adbd3267a0b8868de35b13d58b0b40224',1,'ifxRadar_Matrix.c']]],
  ['matrix_5ftranspose',['MATRIX_TRANSPOSE',['../ifx_radar___matrix_8c.html#a0d7492bd12a071c6e6781bad4ae3653a',1,'ifxRadar_Matrix.c']]],
  ['memory_5falignment',['MEMORY_ALIGNMENT',['../ifx_radar___matrix_8c.html#a184e592fc29c13eab20979a5e4f785a3',1,'MEMORY_ALIGNMENT():&#160;ifxRadar_Matrix.c'],['../ifx_radar___vector_8c.html#a184e592fc29c13eab20979a5e4f785a3',1,'MEMORY_ALIGNMENT():&#160;ifxRadar_Vector.c']]]
];
