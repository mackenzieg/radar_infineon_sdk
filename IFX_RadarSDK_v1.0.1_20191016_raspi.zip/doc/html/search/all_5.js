var searchData=
[
  ['endpoint_5fbase',['endpoint_base',['../structifx___device___controller__s.html#a1e46ef29ef076fb2bf750665a7d5e21d',1,'ifx_Device_Controller_s']]],
  ['endpoint_5fbgt60trxx',['endpoint_bgt60trxx',['../structifx___device___controller__s.html#abd0a36dd914eff4dbcf68b98d5b00104',1,'ifx_Device_Controller_s']]],
  ['endpoint_5fbgt6x',['endpoint_bgt6x',['../structifx___device___controller__s.html#a451796903b21d58fb862f9c132d278c1',1,'ifx_Device_Controller_s']]],
  ['endpoint_5ffmcw',['endpoint_fmcw',['../structifx___device___controller__s.html#a0e44a83ff94bc84ae2efc8cdf80aeeee',1,'ifx_Device_Controller_s']]]
];
