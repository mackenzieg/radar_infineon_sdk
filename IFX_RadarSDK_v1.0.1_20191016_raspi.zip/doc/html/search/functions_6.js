var searchData=
[
  ['translate_5ferror_5fcode',['translate_error_code',['../ifx_radar___device_control_8c.html#a465258f607b9c3a1e6893e8b5936bb8d',1,'ifxRadar_DeviceControl.c']]]
];
