var searchData=
[
  ['output_5fscale_5ftype',['output_scale_type',['../structifx___range___doppler___map__s.html#ad53006cbbc67c14125c27731f59f98e5',1,'ifx_Range_Doppler_Map_s::output_scale_type()'],['../structifx___range___spectrum__s.html#ad53006cbbc67c14125c27731f59f98e5',1,'ifx_Range_Spectrum_s::output_scale_type()'],['../structifx___range___doppler___map___config__t.html#ad53006cbbc67c14125c27731f59f98e5',1,'ifx_Range_Doppler_Map_Config_t::output_scale_type()'],['../structifx___range___spectrum___config__t.html#ad53006cbbc67c14125c27731f59f98e5',1,'ifx_Range_Spectrum_Config_t::output_scale_type()']]]
];
