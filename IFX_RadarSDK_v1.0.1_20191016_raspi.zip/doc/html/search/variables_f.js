var searchData=
[
  ['upper_5ffrequency_5fkhz',['upper_frequency_kHz',['../structifx___device___config__t.html#a095b020d2ada8123b11e9f5ac17547ba',1,'ifx_Device_Config_t']]]
];
