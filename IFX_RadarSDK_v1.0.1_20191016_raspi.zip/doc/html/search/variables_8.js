var searchData=
[
  ['max_5fnum_5fpeaks',['max_num_peaks',['../structifx___peak___search__s.html#a19b63bf143f0010620bc17048364455c',1,'ifx_Peak_Search_s::max_num_peaks()'],['../structifx___peak___search___config__s.html#a19b63bf143f0010620bc17048364455c',1,'ifx_Peak_Search_Config_s::max_num_peaks()']]],
  ['max_5fvalue',['max_value',['../structifx___math___axis___spec__t.html#a44edc6d62a5c7b9ee6945033d859b2c7',1,'ifx_Math_Axis_Spec_t']]],
  ['mean_5fremoval_5fflag',['mean_removal_flag',['../structifx___preprocessed___f_f_t__s.html#af7ab5332bdb95cf668df8536fc423f90',1,'ifx_Preprocessed_FFT_s::mean_removal_flag()'],['../structifx___preprocessed___f_f_t___config__t.html#af7ab5332bdb95cf668df8536fc423f90',1,'ifx_Preprocessed_FFT_Config_t::mean_removal_flag()']]],
  ['min_5fvalue',['min_value',['../structifx___math___axis___spec__t.html#ad056e23a5e184257f0f3c9647c14ada7',1,'ifx_Math_Axis_Spec_t']]],
  ['mode',['mode',['../structifx___range___spectrum__s.html#abd8e1b1119f925d142e8cf95cf6ef34b',1,'ifx_Range_Spectrum_s']]]
];
