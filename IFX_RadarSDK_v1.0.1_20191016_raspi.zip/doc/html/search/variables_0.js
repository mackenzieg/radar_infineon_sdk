var searchData=
[
  ['adc_5fsamplerate_5fhz',['adc_samplerate_hz',['../structifx___device___config__t.html#a87c99bbc1135c0e9634faa99279d5849',1,'ifx_Device_Config_t']]],
  ['alpha_5fmti_5ffilter',['alpha_MTI_filter',['../structifx___m_t_i__s.html#a7b73813140824377d48ffe8b79c93e48',1,'ifx_MTI_s']]],
  ['angle',['angle',['../structifx___polar__s.html#aca49efab93f478d86316c1a7c46d1070',1,'ifx_Polar_s']]],
  ['antenna_5fidx',['antenna_idx',['../structifx___device___frame___state__s.html#a3e7503c5729f5b60f18f4bb416d9f328',1,'ifx_Device_Frame_State_s']]],
  ['at_5fdb',['at_dB',['../structifx___window___config__t.html#ac40eb9bf21e8114b41a81ac85aff1f4c',1,'ifx_Window_Config_t']]]
];
