var searchData=
[
  ['acos',['ACOS',['../ifx_radar___internal_8h.html#ac0968392c2b2fc716807863a5fa7d5f1',1,'ifxRadar_Internal.h']]],
  ['acosh',['ACOSH',['../ifx_radar___internal_8h.html#a59cbf0d6978a854ccf1ee403eecc2f2f',1,'ifxRadar_Internal.h']]],
  ['aligned_5ffree',['ALIGNED_FREE',['../ifx_radar___mem_8c.html#af731de9cc13bd4fef89fbddb7a7e5254',1,'ifxRadar_Mem.c']]],
  ['aligned_5fmalloc',['ALIGNED_MALLOC',['../ifx_radar___mem_8c.html#a83b5d2f9ec5912749f0b90243969338a',1,'ifxRadar_Mem.c']]],
  ['asin',['ASIN',['../ifx_radar___internal_8h.html#a2fefd27702dc315df5aa8418055b9576',1,'ifxRadar_Internal.h']]],
  ['atan',['ATAN',['../ifx_radar___internal_8h.html#a417dfa30ded09b26e9d0216adccab21e',1,'ifxRadar_Internal.h']]],
  ['atan2',['ATAN2',['../ifx_radar___internal_8h.html#ac0c1f033adeb97850cce1712ad1b09e2',1,'ifxRadar_Internal.h']]]
];
