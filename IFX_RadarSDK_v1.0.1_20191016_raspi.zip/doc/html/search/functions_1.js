var searchData=
[
  ['calculate_5fslice_5fsize',['calculate_slice_size',['../ifx_radar___device_control_8c.html#a4f48deefa3c7905307816304f27c4f43',1,'ifxRadar_DeviceControl.c']]],
  ['cheby_5fpoly',['cheby_poly',['../ifx_radar___window_8c.html#af3ab590ed7717a0d6451694f91693c68',1,'ifxRadar_Window.c']]],
  ['connect_5fto_5fdevice',['connect_to_device',['../ifx_radar___device_control_8c.html#a44e7a03c462c3661a8393f8634dee435',1,'ifxRadar_DeviceControl.c']]],
  ['count_5fantennas',['count_antennas',['../ifx_radar___device_control_8c.html#a2b9401c56a75b3cb06586aedee700cd4',1,'ifxRadar_DeviceControl.c']]]
];
