var searchData=
[
  ['num_5fantennas',['num_antennas',['../structifx___device___controller__s.html#a7ada64805ebdd11a60f06be2494ab90a',1,'ifx_Device_Controller_s::num_antennas()'],['../structifx___device___frame___state__s.html#a7ada64805ebdd11a60f06be2494ab90a',1,'ifx_Device_Frame_State_s::num_antennas()']]],
  ['num_5fchirps_5fper_5fframe',['num_chirps_per_frame',['../structifx___device___config__t.html#abfc841b29eafa76af320b80e2431abbb',1,'ifx_Device_Config_t']]],
  ['num_5fof_5fchirps',['num_of_chirps',['../structifx___range___spectrum__s.html#afa3d99ce5a93a7374619cfec54077314',1,'ifx_Range_Spectrum_s']]],
  ['num_5fof_5fchirps_5fper_5fframe',['num_of_chirps_per_frame',['../structifx___range___spectrum___config__t.html#a35dae8ed7edb078bf0ba84867663c766',1,'ifx_Range_Spectrum_Config_t']]],
  ['num_5frx',['num_rx',['../structifx___frame__t.html#a3e801586835019ce481dbae9ea5d97b1',1,'ifx_Frame_t']]],
  ['num_5fsamples',['num_samples',['../structifx___device___frame___state__s.html#ad405b6295e8f021b5a52b8f65f170595',1,'ifx_Device_Frame_State_s']]],
  ['num_5fsamples_5fper_5fchirp',['num_samples_per_chirp',['../structifx___device___config__t.html#ab18a660da006a93d818beab75e58c85e',1,'ifx_Device_Config_t']]]
];
