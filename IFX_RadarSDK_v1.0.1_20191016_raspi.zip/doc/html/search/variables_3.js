var searchData=
[
  ['data',['data',['../structifx___complex__s.html#a534748ee20ea51d3201a1d3ef34574d3',1,'ifx_Complex_s::data()'],['../structifx___matrix___r__t.html#a1704d21cdbdec040155d19632223043d',1,'ifx_Matrix_R_t::data()'],['../structifx___matrix___c__t.html#a5d67cface920506c9ac8dd0c944b4b6f',1,'ifx_Matrix_C_t::data()'],['../structifx___vector___r__t.html#a1704d21cdbdec040155d19632223043d',1,'ifx_Vector_R_t::data()'],['../structifx___vector___c__t.html#a5d67cface920506c9ac8dd0c944b4b6f',1,'ifx_Vector_C_t::data()']]],
  ['device_5fconfig',['device_config',['../structifx___device___controller__s.html#a2d8f0868e06f68fe4d2304399485afaa',1,'ifx_Device_Controller_s']]],
  ['doppler_5ffft_5fconfig',['doppler_fft_config',['../structifx___range___doppler___map___config__t.html#ad0a2430ab86a98a15b256f9133ee2f81',1,'ifx_Range_Doppler_Map_Config_t']]],
  ['doppler_5ffft_5fresult',['doppler_fft_result',['../structifx___range___doppler___map__s.html#a9d78d67f5d4b806934598e5ffd8d1e5a',1,'ifx_Range_Doppler_Map_s']]],
  ['doppler_5fpreprocessed_5ffft_5fhandle',['doppler_preprocessed_fft_handle',['../structifx___range___doppler___map__s.html#a3b516753febd77c9635e9389c52af611',1,'ifx_Range_Doppler_Map_s']]]
];
