var searchData=
[
  ['fft_5fconfig',['fft_config',['../structifx___range___spectrum___config__t.html#a89cfbdb1b8fa60d1f545e2ea194f9e16',1,'ifx_Range_Spectrum_Config_t']]],
  ['fft_5ffreq_5faxis_5fspec_5fkhz',['fft_freq_axis_spec_khz',['../structifx___preprocessed___f_f_t__s.html#aa4158b1deeecc18ca2e0cf4df0903e84',1,'ifx_Preprocessed_FFT_s']]],
  ['fft_5fhandle',['fft_handle',['../structifx___preprocessed___f_f_t__s.html#a417cf99ef73a5d0a49366b5184e4de81',1,'ifx_Preprocessed_FFT_s']]],
  ['fft_5finput_5flen',['fft_input_len',['../structifx___f_f_t__s.html#a30f3b4337cdf6c333cb650599a3eaa63',1,'ifx_FFT_s::fft_input_len()'],['../structifx___preprocessed___f_f_t___config__t.html#a30f3b4337cdf6c333cb650599a3eaa63',1,'ifx_Preprocessed_FFT_Config_t::fft_input_len()']]],
  ['fft_5fmatrix',['fft_matrix',['../structifx___range___doppler___map__s.html#a9fae9986e1c6fbd99c46effc228da137',1,'ifx_Range_Doppler_Map_s']]],
  ['fft_5fmean_5fresult',['fft_mean_result',['../structifx___range___spectrum__s.html#a78ec7507941f794beef8daecf7b9f32d',1,'ifx_Range_Spectrum_s']]],
  ['fft_5fresult',['fft_result',['../structifx___preprocessed___f_f_t__s.html#aa76583b10e8a34a323ba8b12906bcd56',1,'ifx_Preprocessed_FFT_s::fft_result()'],['../structifx___range___spectrum__s.html#aa76583b10e8a34a323ba8b12906bcd56',1,'ifx_Range_Spectrum_s::fft_result()']]],
  ['fft_5fsize',['fft_size',['../structifx___f_f_t__s.html#a01dcb5abf4eaab7937387e6021ba9de6',1,'ifx_FFT_s::fft_size()'],['../structifx___preprocessed___f_f_t___config__t.html#a01dcb5abf4eaab7937387e6021ba9de6',1,'ifx_Preprocessed_FFT_Config_t::fft_size()']]],
  ['fft_5fspectrum_5fmatrix',['fft_spectrum_matrix',['../structifx___range___spectrum__s.html#a5b90f7b0f70dae71cad3d32e210c0222',1,'ifx_Range_Spectrum_s']]],
  ['fft_5ftype',['fft_type',['../structifx___f_f_t__s.html#a5e55069d1b92a17568e7095593121b5b',1,'ifx_FFT_s::fft_type()'],['../structifx___preprocessed___f_f_t___config__t.html#a5e55069d1b92a17568e7095593121b5b',1,'ifx_Preprocessed_FFT_Config_t::fft_type()']]],
  ['fft_5fwindow',['fft_window',['../structifx___preprocessed___f_f_t__s.html#ac960236ab59da2bc004c17b851988e3e',1,'ifx_Preprocessed_FFT_s']]],
  ['frame',['frame',['../structifx___device___frame___state__s.html#ad8a80a3ae0cbc2fdecd18f4cf3ba2eb0',1,'ifx_Device_Frame_State_s']]],
  ['frame_5fend_5fdelay_5f100ps',['frame_end_delay_100ps',['../structifx___device___config__t.html#ababc8778a4fb91ed74e9289ccf0a10d4',1,'ifx_Device_Config_t']]],
  ['frame_5fperiod_5fus',['frame_period_us',['../structifx___device___config__t.html#a8a0a0bcf21f5099b0e61a1100ed0a517',1,'ifx_Device_Config_t']]]
];
