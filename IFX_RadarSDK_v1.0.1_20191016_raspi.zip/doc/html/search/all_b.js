var searchData=
[
  ['main_5fdoxy_2eh',['main_doxy.h',['../../../../../radar_transceiver/build/doc_html/html/main__doxy_8h.html',1,'']]],
  ['matrix_5fclone',['MATRIX_CLONE',['../ifx_radar___matrix_8c.html#a51743f0a1368d7cc9a0800fdd9215aed',1,'ifxRadar_Matrix.c']]],
  ['matrix_5fcopy',['MATRIX_COPY',['../ifx_radar___matrix_8c.html#af9267329964671ee9ac24c0bda60c93d',1,'ifxRadar_Matrix.c']]],
  ['matrix_5fget_5felement',['MATRIX_GET_ELEMENT',['../ifx_radar___matrix_8c.html#a8aaaff496c595725e77638928862c87c',1,'ifxRadar_Matrix.c']]],
  ['matrix_5fis_5fdim_5fsame',['MATRIX_IS_DIM_SAME',['../ifx_radar___matrix_8c.html#adbd3267a0b8868de35b13d58b0b40224',1,'ifxRadar_Matrix.c']]],
  ['matrix_5ftranspose',['MATRIX_TRANSPOSE',['../ifx_radar___matrix_8c.html#a0d7492bd12a071c6e6781bad4ae3653a',1,'ifxRadar_Matrix.c']]],
  ['max_5fnum_5fpeaks',['max_num_peaks',['../structifx___peak___search__s.html#a19b63bf143f0010620bc17048364455c',1,'ifx_Peak_Search_s::max_num_peaks()'],['../structifx___peak___search___config__s.html#a19b63bf143f0010620bc17048364455c',1,'ifx_Peak_Search_Config_s::max_num_peaks()']]],
  ['max_5fvalue',['max_value',['../structifx___math___axis___spec__t.html#a44edc6d62a5c7b9ee6945033d859b2c7',1,'ifx_Math_Axis_Spec_t']]],
  ['mean_5fremoval_5fflag',['mean_removal_flag',['../structifx___preprocessed___f_f_t__s.html#af7ab5332bdb95cf668df8536fc423f90',1,'ifx_Preprocessed_FFT_s::mean_removal_flag()'],['../structifx___preprocessed___f_f_t___config__t.html#af7ab5332bdb95cf668df8536fc423f90',1,'ifx_Preprocessed_FFT_Config_t::mean_removal_flag()']]],
  ['memory_5falignment',['MEMORY_ALIGNMENT',['../ifx_radar___matrix_8c.html#a184e592fc29c13eab20979a5e4f785a3',1,'MEMORY_ALIGNMENT():&#160;ifxRadar_Matrix.c'],['../ifx_radar___vector_8c.html#a184e592fc29c13eab20979a5e4f785a3',1,'MEMORY_ALIGNMENT():&#160;ifxRadar_Vector.c']]],
  ['min_5fvalue',['min_value',['../structifx___math___axis___spec__t.html#ad056e23a5e184257f0f3c9647c14ada7',1,'ifx_Math_Axis_Spec_t']]],
  ['mode',['mode',['../structifx___range___spectrum__s.html#abd8e1b1119f925d142e8cf95cf6ef34b',1,'ifx_Range_Spectrum_s']]]
];
