var searchData=
[
  ['threshold_5ffactor',['threshold_factor',['../structifx___peak___search__s.html#ad3758d5515690877e2250ef192eef210',1,'ifx_Peak_Search_s::threshold_factor()'],['../structifx___peak___search___config__s.html#ad3758d5515690877e2250ef192eef210',1,'ifx_Peak_Search_Config_s::threshold_factor()']]],
  ['threshold_5foffset',['threshold_offset',['../structifx___peak___search__s.html#aa355556241f4f20ce4fbb5f4c2789a58',1,'ifx_Peak_Search_s::threshold_offset()'],['../structifx___peak___search___config__s.html#aa355556241f4f20ce4fbb5f4c2789a58',1,'ifx_Peak_Search_Config_s::threshold_offset()']]],
  ['total_5fmem',['TOTAL_MEM',['../ifx_radar___mem_8c.html#a69c48f4fe50151ac0b9cd2a14417c5b7',1,'ifxRadar_Mem.c']]],
  ['track_5fmem',['TRACK_MEM',['../ifx_radar___mem_8c.html#a390ba827427d8c91ffb41ca1b69e95bc',1,'ifxRadar_Mem.c']]],
  ['translate_5ferror_5fcode',['translate_error_code',['../ifx_radar___device_control_8c.html#a465258f607b9c3a1e6893e8b5936bb8d',1,'ifxRadar_DeviceControl.c']]],
  ['transposed_5frange_5ffft_5fmatrix',['transposed_range_fft_matrix',['../structifx___range___doppler___map__s.html#a124045284e19c2eb6af15e34dbc60da7',1,'ifx_Range_Doppler_Map_s']]],
  ['type',['type',['../structifx___window___config__t.html#a01a3f8194c4c8507f7f65d4cb9c25697',1,'ifx_Window_Config_t']]]
];
