var searchData=
[
  ['radar_5fsdk_5fversion_5fstr',['RADAR_SDK_VERSION_STR',['../ifx_radar___version_8c.html#aadfb3ffc8bc477176d75d5100ea58598',1,'ifxRadar_Version.c']]],
  ['ramp_5fend_5fdelay_5f100ps',['RAMP_END_DELAY_100PS',['../ifx_radar___device_control_8c.html#a1250d386aa977b86f977bd8a4bba0a4e',1,'ifxRadar_DeviceControl.c']]],
  ['range_5fdoppler_5fspec',['RANGE_DOPPLER_SPEC',['../ifx_radar___range_doppler_map_8c.html#abc45a4c356c89eb9b47d02dcbb8be0e9',1,'ifxRadar_RangeDopplerMap.c']]],
  ['range_5fspec',['RANGE_SPEC',['../ifx_radar___range_spectrum_8c.html#a0843f9f33f4c373b995b66700a89b988',1,'ifxRadar_RangeSpectrum.c']]]
];
