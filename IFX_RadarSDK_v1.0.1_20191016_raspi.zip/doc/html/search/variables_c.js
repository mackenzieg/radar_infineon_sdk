var searchData=
[
  ['radar_5fsdk_5fversion',['RADAR_SDK_VERSION',['../ifx_radar___version_8c.html#a8884bb7995ca54488a36bc8e79f34a9e',1,'ifxRadar_Version.c']]],
  ['radius',['radius',['../structifx___polar__s.html#a9057f3cfe5bc97d4def1a8c06c620153',1,'ifx_Polar_s']]],
  ['range_5faxis_5fspec_5fm',['range_axis_spec_m',['../structifx___range___doppler___map__s.html#ad8f60ebda6dc235eca43961bc3aa37d6',1,'ifx_Range_Doppler_Map_s::range_axis_spec_m()'],['../structifx___range___spectrum__s.html#ad8f60ebda6dc235eca43961bc3aa37d6',1,'ifx_Range_Spectrum_s::range_axis_spec_m()']]],
  ['range_5ffft_5fconfig',['range_fft_config',['../structifx___range___doppler___map___config__t.html#abc9d80b6665542798f3d4e756d4f4dad',1,'ifx_Range_Doppler_Map_Config_t']]],
  ['range_5fpreprocessed_5ffft_5fhandle',['range_preprocessed_fft_handle',['../structifx___range___doppler___map__s.html#aba40bb3da896694665339268059a1ae8',1,'ifx_Range_Doppler_Map_s']]],
  ['rows',['rows',['../structifx___matrix___r__t.html#a11fd148437f8e38e54464cd7ec795c0e',1,'ifx_Matrix_R_t::rows()'],['../structifx___matrix___c__t.html#a11fd148437f8e38e54464cd7ec795c0e',1,'ifx_Matrix_C_t::rows()']]],
  ['rx_5fantenna_5fmask',['rx_antenna_mask',['../structifx___device___config__t.html#af283e9b1ea00cc2669ac6371095f9907',1,'ifx_Device_Config_t']]],
  ['rx_5fdata',['rx_data',['../structifx___frame__t.html#ac9c179eab19f7f2d2946ed612dafd311',1,'ifx_Frame_t']]]
];
