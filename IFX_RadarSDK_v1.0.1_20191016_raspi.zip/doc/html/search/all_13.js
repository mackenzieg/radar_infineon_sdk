var searchData=
[
  ['value_5fbin_5fper_5fstep',['value_bin_per_step',['../structifx___math___axis___spec__t.html#aa38bf842e2bd327ebf854b1ee28c4d1a',1,'ifx_Math_Axis_Spec_t']]],
  ['value_5fper_5fbin',['value_per_bin',['../structifx___peak___search__s.html#aade6e9e5790ccd07cc586905c4749200',1,'ifx_Peak_Search_s::value_per_bin()'],['../structifx___peak___search___config__s.html#aade6e9e5790ccd07cc586905c4749200',1,'ifx_Peak_Search_Config_s::value_per_bin()']]]
];
