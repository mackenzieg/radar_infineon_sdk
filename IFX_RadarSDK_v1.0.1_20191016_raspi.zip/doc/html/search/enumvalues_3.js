var searchData=
[
  ['scale_5ftype_5fdecibel_5f10log',['SCALE_TYPE_DECIBEL_10LOG',['../ifx_radar___math_8h.html#a043c0d0010914fa5abd8da217e624237a80ad6a873968be1598dae0329c9701cf',1,'ifxRadar_Math.h']]],
  ['scale_5ftype_5fdecibel_5f20log',['SCALE_TYPE_DECIBEL_20LOG',['../ifx_radar___math_8h.html#a043c0d0010914fa5abd8da217e624237a258e10434bbff1cd13ad8dc543749695',1,'ifxRadar_Math.h']]],
  ['scale_5ftype_5flinear',['SCALE_TYPE_LINEAR',['../ifx_radar___math_8h.html#a043c0d0010914fa5abd8da217e624237afd085853049ae7f997d026dbc4c70b15',1,'ifxRadar_Math.h']]]
];
