var searchData=
[
  ['pow',['POW',['../ifx_radar___internal_8h.html#a7d36eb793ee8943f856044317659fbf1',1,'ifxRadar_Internal.h']]],
  ['preprocessed_5ffft',['PREPROCESSED_FFT',['../ifx_radar___preprocessed_f_f_t_8c.html#a5595f16de47929d71f3cc606e904577d',1,'ifxRadar_PreprocessedFFT.c']]]
];
