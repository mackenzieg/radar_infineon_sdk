var searchData=
[
  ['cabs',['CABS',['../ifx_radar___internal_8h.html#ac6945cb7d2db8f89f9eac901caa7d67a',1,'ifxRadar_Internal.h']]],
  ['check_5fcall_5fdestroy_5freturn',['CHECK_CALL_DESTROY_RETURN',['../ifx_radar___f_f_t_8c.html#aedc29842ab9feeef525b0eb2b7877a69',1,'CHECK_CALL_DESTROY_RETURN():&#160;ifxRadar_FFT.c'],['../ifx_radar___preprocessed_f_f_t_8c.html#aedc29842ab9feeef525b0eb2b7877a69',1,'CHECK_CALL_DESTROY_RETURN():&#160;ifxRadar_PreprocessedFFT.c'],['../ifx_radar___range_doppler_map_8c.html#aedc29842ab9feeef525b0eb2b7877a69',1,'CHECK_CALL_DESTROY_RETURN():&#160;ifxRadar_RangeDopplerMap.c'],['../ifx_radar___range_spectrum_8c.html#aedc29842ab9feeef525b0eb2b7877a69',1,'CHECK_CALL_DESTROY_RETURN():&#160;ifxRadar_RangeSpectrum.c']]],
  ['check_5fcomm_5ferr_5fcode',['CHECK_COMM_ERR_CODE',['../ifx_radar___device_control_8c.html#ad30adefdcac60d74a21d99d0a9f66360',1,'ifxRadar_DeviceControl.c']]],
  ['cimag',['CIMAG',['../ifx_radar___internal_8h.html#a4b305e7c9cd60987bfcd8d953c19687c',1,'ifxRadar_Internal.h']]],
  ['clipping_5fvalue',['CLIPPING_VALUE',['../ifx_radar___range_doppler_map_8c.html#a550b1544733c642e2e37edb3f35fb805',1,'CLIPPING_VALUE():&#160;ifxRadar_RangeDopplerMap.c'],['../ifx_radar___range_spectrum_8c.html#a550b1544733c642e2e37edb3f35fb805',1,'CLIPPING_VALUE():&#160;ifxRadar_RangeSpectrum.c']]],
  ['cos',['COS',['../ifx_radar___internal_8h.html#af1af2de870caad797b91210f0fc6fe78',1,'ifxRadar_Internal.h']]],
  ['cosh',['COSH',['../ifx_radar___internal_8h.html#a06122bdfd04092936fac23f4de42d468',1,'ifxRadar_Internal.h']]],
  ['creal',['CREAL',['../ifx_radar___internal_8h.html#aadc886cc580025d6849ac82b0a8f7cf5',1,'ifxRadar_Internal.h']]]
];
