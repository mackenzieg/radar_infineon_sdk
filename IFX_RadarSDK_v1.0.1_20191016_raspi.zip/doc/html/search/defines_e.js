var searchData=
[
  ['total_5fmem',['TOTAL_MEM',['../ifx_radar___mem_8c.html#a69c48f4fe50151ac0b9cd2a14417c5b7',1,'ifxRadar_Mem.c']]],
  ['track_5fmem',['TRACK_MEM',['../ifx_radar___mem_8c.html#a390ba827427d8c91ffb41ca1b69e95bc',1,'ifxRadar_Mem.c']]]
];
