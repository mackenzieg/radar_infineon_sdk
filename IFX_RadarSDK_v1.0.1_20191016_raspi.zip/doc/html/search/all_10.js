var searchData=
[
  ['software_20stack',['Software Stack',['../pg_radarsdk.html',1,'']]],
  ['system_20setup',['System Setup',['../../../../../radar_transceiver/build/doc_html/html/pg_radarsdk_sys.html',1,'']]],
  ['sample_5fidx',['sample_idx',['../structifx___device___frame___state__s.html#aecf2ef6c211b9f60f0596dcb6d9b92a7',1,'ifx_Device_Frame_State_s']]],
  ['scale_5ftype_5fdecibel_5f10log',['SCALE_TYPE_DECIBEL_10LOG',['../ifx_radar___math_8h.html#a043c0d0010914fa5abd8da217e624237a80ad6a873968be1598dae0329c9701cf',1,'ifxRadar_Math.h']]],
  ['scale_5ftype_5fdecibel_5f20log',['SCALE_TYPE_DECIBEL_20LOG',['../ifx_radar___math_8h.html#a043c0d0010914fa5abd8da217e624237a258e10434bbff1cd13ad8dc543749695',1,'ifxRadar_Math.h']]],
  ['scale_5ftype_5flinear',['SCALE_TYPE_LINEAR',['../ifx_radar___math_8h.html#a043c0d0010914fa5abd8da217e624237afd085853049ae7f997d026dbc4c70b15',1,'ifxRadar_Math.h']]],
  ['search_5fendpoints',['search_endpoints',['../ifx_radar___device_control_8c.html#a8e7b437f0a1caef7b5545e666daccb07',1,'ifxRadar_DeviceControl.c']]],
  ['search_5fzone_5fend',['search_zone_end',['../structifx___peak___search__s.html#ab031779afe0bb8dc14a2af6354e24aa7',1,'ifx_Peak_Search_s::search_zone_end()'],['../structifx___peak___search___config__s.html#ab031779afe0bb8dc14a2af6354e24aa7',1,'ifx_Peak_Search_Config_s::search_zone_end()']]],
  ['search_5fzone_5fstart',['search_zone_start',['../structifx___peak___search__s.html#a086a604d01bf621e310a0f62a784fe76',1,'ifx_Peak_Search_s::search_zone_start()'],['../structifx___peak___search___config__s.html#a086a604d01bf621e310a0f62a784fe76',1,'ifx_Peak_Search_Config_s::search_zone_start()']]],
  ['shape_5f1_5fnum_5frepititions',['SHAPE_1_NUM_REPITITIONS',['../ifx_radar___device_control_8c.html#a49400cb15f8cc4098e5e200cb276e4a3',1,'ifxRadar_DeviceControl.c']]],
  ['shape_5fend_5fdelay_5f100ps',['shape_end_delay_100ps',['../structifx___device___config__t.html#a376ae61e8f99069802efa14489f418aa',1,'ifx_Device_Config_t']]],
  ['sin',['SIN',['../ifx_radar___internal_8h.html#ac80ce9955a1af2ab7aa3a67251ec9f5c',1,'ifxRadar_Internal.h']]],
  ['single_5fchirp_5fmode_5findex',['single_chirp_mode_index',['../structifx___range___spectrum__s.html#add18eaf435ea3ff5326a3de811bc8b9d',1,'ifx_Range_Spectrum_s']]],
  ['size',['size',['../structifx___window___config__t.html#ab2c6b258f02add8fdf4cfc7c371dd772',1,'ifx_Window_Config_t']]],
  ['spect_5fthreshold',['spect_threshold',['../structifx___range___doppler___map__s.html#adb93ab255f33613617cad8875e760bc4',1,'ifx_Range_Doppler_Map_s::spect_threshold()'],['../structifx___range___spectrum__s.html#adb93ab255f33613617cad8875e760bc4',1,'ifx_Range_Spectrum_s::spect_threshold()'],['../structifx___range___doppler___map___config__t.html#adb93ab255f33613617cad8875e760bc4',1,'ifx_Range_Doppler_Map_Config_t::spect_threshold()'],['../structifx___range___spectrum___config__t.html#adb93ab255f33613617cad8875e760bc4',1,'ifx_Range_Spectrum_Config_t::spect_threshold()']]],
  ['spectrum_5fhistory',['spectrum_history',['../structifx___m_t_i__s.html#a2fc40979b571fb4be33830ce7b0f6893',1,'ifx_MTI_s']]],
  ['spectrum_5ftemp',['spectrum_temp',['../structifx___m_t_i__s.html#a37863de8019ea064edd4cbd785e7c993',1,'ifx_MTI_s']]],
  ['speed_5faxis_5fspec_5fmps',['speed_axis_spec_mps',['../structifx___range___doppler___map__s.html#a39e06e91d6736121abbfcb9f2b67a08c',1,'ifx_Range_Doppler_Map_s']]],
  ['status',['status',['../structifx___device___frame___state__s.html#a8b2966f11e47af4858eae768d82dce1b',1,'ifx_Device_Frame_State_s']]],
  ['str',['STR',['../ifx_radar___version_8c.html#a18d295a837ac71add5578860b55e5502',1,'ifxRadar_Version.c']]]
];
