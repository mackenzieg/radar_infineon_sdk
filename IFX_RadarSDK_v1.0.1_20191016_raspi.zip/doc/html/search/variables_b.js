var searchData=
[
  ['peak_5fcount',['peak_count',['../structifx___peak___search__s.html#a5756f81bbde9d2af16889cc6302f8656',1,'ifx_Peak_Search_s::peak_count()'],['../structifx___peak___search___result__t.html#a5756f81bbde9d2af16889cc6302f8656',1,'ifx_Peak_Search_Result_t::peak_count()']]],
  ['peak_5fidx',['peak_idx',['../structifx___peak___search__s.html#a47f323e8270e7a4f4380ca8418af0e0b',1,'ifx_Peak_Search_s']]],
  ['peak_5fval',['peak_val',['../structifx___peak___search__s.html#adf20a2c5f94a6e3309333f163a6e7676',1,'ifx_Peak_Search_s']]],
  ['preprocessed_5ffft_5fhandle',['preprocessed_fft_handle',['../structifx___range___spectrum__s.html#aef21ef203971d5ba1a677a84c7308fac',1,'ifx_Range_Spectrum_s']]],
  ['preprocessing_5fresult_5fc',['preprocessing_result_c',['../structifx___preprocessed___f_f_t__s.html#a2c4d3c3df78292d462f9e0db591c30fd',1,'ifx_Preprocessed_FFT_s']]],
  ['preprocessing_5fresult_5fr',['preprocessing_result_r',['../structifx___preprocessed___f_f_t__s.html#af791f26f4bdfe3c7ac901e9c31d76b1a',1,'ifx_Preprocessed_FFT_s']]],
  ['protocol_5fhandle',['protocol_handle',['../structifx___device___controller__s.html#a82c95089330af2c65104f8bb26c6f1bc',1,'ifx_Device_Controller_s']]]
];
