var searchData=
[
  ['center_5ffrequency_5fkhz',['center_frequency_khz',['../structifx___range___doppler___map___config__t.html#a761e2c3209f2b192fb62f2e1041a1c3f',1,'ifx_Range_Doppler_Map_Config_t']]],
  ['chirp_5fbandwidth_5fkhz',['chirp_bandwidth_khz',['../structifx___range___doppler___map___config__t.html#a9241c76520dbf2259592f47696f41713',1,'ifx_Range_Doppler_Map_Config_t::chirp_bandwidth_khz()'],['../structifx___range___spectrum___config__t.html#a50bee4ff851d220c61ddac9cad5982ea',1,'ifx_Range_Spectrum_Config_t::chirp_bandwidth_khz()']]],
  ['chirp_5fidx',['chirp_idx',['../structifx___device___frame___state__s.html#a892c2a14166d7a20f29c6775cd359c79',1,'ifx_Device_Frame_State_s']]],
  ['chirp_5frepetition_5ftime_5fsec',['chirp_repetition_time_sec',['../structifx___range___doppler___map___config__t.html#a72d1b9f9b6b0a398f7dba2b8b197ac47',1,'ifx_Range_Doppler_Map_Config_t']]],
  ['chirp_5fto_5fchirp_5ftime_5f100ps',['chirp_to_chirp_time_100ps',['../structifx___device___config__t.html#a70e3c1e1c9b0f1545240e3594990194b',1,'ifx_Device_Config_t']]],
  ['columns',['columns',['../structifx___matrix___r__t.html#a56664eb80ec4f50e9fd0419e2eb335ca',1,'ifx_Matrix_R_t::columns()'],['../structifx___matrix___c__t.html#a56664eb80ec4f50e9fd0419e2eb335ca',1,'ifx_Matrix_C_t::columns()']]]
];
