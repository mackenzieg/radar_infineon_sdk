var searchData=
[
  ['threshold_5ffactor',['threshold_factor',['../structifx___peak___search__s.html#ad3758d5515690877e2250ef192eef210',1,'ifx_Peak_Search_s::threshold_factor()'],['../structifx___peak___search___config__s.html#ad3758d5515690877e2250ef192eef210',1,'ifx_Peak_Search_Config_s::threshold_factor()']]],
  ['threshold_5foffset',['threshold_offset',['../structifx___peak___search__s.html#aa355556241f4f20ce4fbb5f4c2789a58',1,'ifx_Peak_Search_s::threshold_offset()'],['../structifx___peak___search___config__s.html#aa355556241f4f20ce4fbb5f4c2789a58',1,'ifx_Peak_Search_Config_s::threshold_offset()']]],
  ['transposed_5frange_5ffft_5fmatrix',['transposed_range_fft_matrix',['../structifx___range___doppler___map__s.html#a124045284e19c2eb6af15e34dbc60da7',1,'ifx_Range_Doppler_Map_s']]],
  ['type',['type',['../structifx___window___config__t.html#a01a3f8194c4c8507f7f65d4cb9c25697',1,'ifx_Window_Config_t']]]
];
