var structifx___polar__s =
[
    [ "angle", "structifx___polar__s.html#aca49efab93f478d86316c1a7c46d1070", null ],
    [ "radius", "structifx___polar__s.html#a9057f3cfe5bc97d4def1a8c06c620153", null ]
];