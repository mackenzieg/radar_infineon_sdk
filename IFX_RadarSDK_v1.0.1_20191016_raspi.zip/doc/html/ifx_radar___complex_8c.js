var ifx_radar___complex_8c =
[
    [ "ifx_complex_abs", "ifx_radar___complex_8c.html#ad31b3de5cdf1d6fd3c22cb996fe30660", null ],
    [ "ifx_complex_add", "ifx_radar___complex_8c.html#a46041120c1e56eafb91b9c1f2cabf4b6", null ],
    [ "ifx_complex_add_scalar", "ifx_radar___complex_8c.html#af4a8ff572eab995db6a3d1f7a2aa68ac", null ],
    [ "ifx_complex_arg", "ifx_radar___complex_8c.html#a09680d06aa2e37a8c5d4dd57144e3aeb", null ],
    [ "ifx_complex_conj", "ifx_radar___complex_8c.html#a9c98f41de6dab9f04f71ea8578647fdf", null ],
    [ "ifx_complex_div", "ifx_radar___complex_8c.html#a3737841740db19c2ce6b4d59a8287d70", null ],
    [ "ifx_complex_div_scalar", "ifx_radar___complex_8c.html#acdc8ff956400a9aaf02a44df835897e8", null ],
    [ "ifx_complex_from_polar", "ifx_radar___complex_8c.html#aad0e26c570d83cf8fee6678c675c8901", null ],
    [ "ifx_complex_ln", "ifx_radar___complex_8c.html#aa94c102941759a3e0857cdfd65efc752", null ],
    [ "ifx_complex_log10", "ifx_radar___complex_8c.html#abc3507241521db5f47ac4a191d8dc628", null ],
    [ "ifx_complex_mul", "ifx_radar___complex_8c.html#ab1d93633c6e2bb262298ab798647cc5e", null ],
    [ "ifx_complex_mul_scalar", "ifx_radar___complex_8c.html#ad64fbfdd8d942ba782a804ee29e997b6", null ],
    [ "ifx_complex_sub", "ifx_radar___complex_8c.html#a9bf94373e5a3bc5e9e2d55ce6629f9ef", null ],
    [ "ifx_complex_sub_scalar", "ifx_radar___complex_8c.html#aa6cfcce6fd7da85a98dd2ef6ad1c03cf", null ],
    [ "ifx_complex_to_polar", "ifx_radar___complex_8c.html#abe053442cca29b08f7cb0d0ca7f456bb", null ]
];