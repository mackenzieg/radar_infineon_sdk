var structifx___range___doppler___map__s =
[
    [ "doppler_fft_result", "structifx___range___doppler___map__s.html#a9d78d67f5d4b806934598e5ffd8d1e5a", null ],
    [ "doppler_preprocessed_fft_handle", "structifx___range___doppler___map__s.html#a3b516753febd77c9635e9389c52af611", null ],
    [ "fft_matrix", "structifx___range___doppler___map__s.html#a9fae9986e1c6fbd99c46effc228da137", null ],
    [ "output_scale_type", "structifx___range___doppler___map__s.html#ad53006cbbc67c14125c27731f59f98e5", null ],
    [ "range_axis_spec_m", "structifx___range___doppler___map__s.html#ad8f60ebda6dc235eca43961bc3aa37d6", null ],
    [ "range_preprocessed_fft_handle", "structifx___range___doppler___map__s.html#aba40bb3da896694665339268059a1ae8", null ],
    [ "spect_threshold", "structifx___range___doppler___map__s.html#adb93ab255f33613617cad8875e760bc4", null ],
    [ "speed_axis_spec_mps", "structifx___range___doppler___map__s.html#a39e06e91d6736121abbfcb9f2b67a08c", null ],
    [ "transposed_range_fft_matrix", "structifx___range___doppler___map__s.html#a124045284e19c2eb6af15e34dbc60da7", null ]
];