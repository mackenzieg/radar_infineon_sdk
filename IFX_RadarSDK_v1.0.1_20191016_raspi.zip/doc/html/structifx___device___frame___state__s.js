var structifx___device___frame___state__s =
[
    [ "antenna_idx", "structifx___device___frame___state__s.html#a3e7503c5729f5b60f18f4bb416d9f328", null ],
    [ "chirp_idx", "structifx___device___frame___state__s.html#a892c2a14166d7a20f29c6775cd359c79", null ],
    [ "frame", "structifx___device___frame___state__s.html#ad8a80a3ae0cbc2fdecd18f4cf3ba2eb0", null ],
    [ "num_antennas", "structifx___device___frame___state__s.html#a7ada64805ebdd11a60f06be2494ab90a", null ],
    [ "num_samples", "structifx___device___frame___state__s.html#ad405b6295e8f021b5a52b8f65f170595", null ],
    [ "sample_idx", "structifx___device___frame___state__s.html#aecf2ef6c211b9f60f0596dcb6d9b92a7", null ],
    [ "status", "structifx___device___frame___state__s.html#a8b2966f11e47af4858eae768d82dce1b", null ]
];