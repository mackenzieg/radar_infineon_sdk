var ifx_radar___mem_8h =
[
    [ "ifx_mem_aligned_alloc", "ifx_radar___mem_8h.html#a7e7a09693e3e47510a771b356f25d29e", null ],
    [ "ifx_mem_aligned_free", "ifx_radar___mem_8h.html#a3ff07fb6789dadf1d89dc68bae5d8697", null ],
    [ "ifx_mem_alloc", "ifx_radar___mem_8h.html#aa9ecfd0f473eb3e279e3a1fac86f47f8", null ],
    [ "ifx_mem_calloc", "ifx_radar___mem_8h.html#af6ddd82d94ade65fc5e7bd3cd3618c8a", null ],
    [ "ifx_mem_free", "ifx_radar___mem_8h.html#a97222be1e319035121a5694f629de8d9", null ],
    [ "ifx_mem_get_total_alloc_size", "ifx_radar___mem_8h.html#a077659f1e7b286bb9ebcfad127c6d130", null ]
];