var ifx_radar___version_8c =
[
    [ "DELIMITER", "ifx_radar___version_8c.html#a23195218eef2cf21e2beae685a041783", null ],
    [ "RADAR_SDK_VERSION_STR", "ifx_radar___version_8c.html#aadfb3ffc8bc477176d75d5100ea58598", null ],
    [ "STR", "ifx_radar___version_8c.html#a18d295a837ac71add5578860b55e5502", null ],
    [ "XSTR", "ifx_radar___version_8c.html#abe87b341f562fd1cf40b7672e4d759da", null ],
    [ "ifx_radar_sdk_get_version_string", "ifx_radar___version_8c.html#a7269c6cde2ac9828adb915a781cae762", null ],
    [ "RADAR_SDK_VERSION", "ifx_radar___version_8c.html#a8884bb7995ca54488a36bc8e79f34a9e", null ]
];