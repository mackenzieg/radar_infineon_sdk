var structifx___math___axis___spec__t =
[
    [ "max_value", "structifx___math___axis___spec__t.html#a44edc6d62a5c7b9ee6945033d859b2c7", null ],
    [ "min_value", "structifx___math___axis___spec__t.html#ad056e23a5e184257f0f3c9647c14ada7", null ],
    [ "value_bin_per_step", "structifx___math___axis___spec__t.html#aa38bf842e2bd327ebf854b1ee28c4d1a", null ]
];