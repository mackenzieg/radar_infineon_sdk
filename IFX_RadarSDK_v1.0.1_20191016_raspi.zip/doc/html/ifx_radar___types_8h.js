var ifx_radar___types_8h =
[
    [ "ifx_Polar_s", "structifx___polar__s.html", "structifx___polar__s" ],
    [ "ifx_Float_t", "ifx_radar___types_8h.html#a39079719d81fd7bcf3cd5113a6dbe905", null ],
    [ "ifx_Polar_t", "ifx_radar___types_8h.html#a038d967a9d25c23b4aa2b3a44ad130f5", null ]
];