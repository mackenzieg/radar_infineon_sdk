var structifx___matrix___r__t =
[
    [ "columns", "structifx___matrix___r__t.html#a56664eb80ec4f50e9fd0419e2eb335ca", null ],
    [ "data", "structifx___matrix___r__t.html#a1704d21cdbdec040155d19632223043d", null ],
    [ "rows", "structifx___matrix___r__t.html#a11fd148437f8e38e54464cd7ec795c0e", null ]
];