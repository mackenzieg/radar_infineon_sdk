var structifx___m_t_i__s =
[
    [ "alpha_MTI_filter", "structifx___m_t_i__s.html#a7b73813140824377d48ffe8b79c93e48", null ],
    [ "spectrum_history", "structifx___m_t_i__s.html#a2fc40979b571fb4be33830ce7b0f6893", null ],
    [ "spectrum_temp", "structifx___m_t_i__s.html#a37863de8019ea064edd4cbd785e7c993", null ]
];