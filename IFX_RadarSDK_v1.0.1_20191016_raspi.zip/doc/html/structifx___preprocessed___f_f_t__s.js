var structifx___preprocessed___f_f_t__s =
[
    [ "fft_freq_axis_spec_khz", "structifx___preprocessed___f_f_t__s.html#aa4158b1deeecc18ca2e0cf4df0903e84", null ],
    [ "fft_handle", "structifx___preprocessed___f_f_t__s.html#a417cf99ef73a5d0a49366b5184e4de81", null ],
    [ "fft_result", "structifx___preprocessed___f_f_t__s.html#aa76583b10e8a34a323ba8b12906bcd56", null ],
    [ "fft_window", "structifx___preprocessed___f_f_t__s.html#ac960236ab59da2bc004c17b851988e3e", null ],
    [ "mean_removal_flag", "structifx___preprocessed___f_f_t__s.html#af7ab5332bdb95cf668df8536fc423f90", null ],
    [ "preprocessing_result_c", "structifx___preprocessed___f_f_t__s.html#a2c4d3c3df78292d462f9e0db591c30fd", null ],
    [ "preprocessing_result_r", "structifx___preprocessed___f_f_t__s.html#af791f26f4bdfe3c7ac901e9c31d76b1a", null ]
];