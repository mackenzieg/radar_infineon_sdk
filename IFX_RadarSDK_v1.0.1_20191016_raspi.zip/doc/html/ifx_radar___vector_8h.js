var ifx_radar___vector_8h =
[
    [ "ifx_Vector_R_t", "structifx___vector___r__t.html", "structifx___vector___r__t" ],
    [ "ifx_Vector_C_t", "structifx___vector___c__t.html", "structifx___vector___c__t" ],
    [ "ifx_vector_copy_c", "ifx_radar___vector_8h.html#a566a33386e7b5ae4bc28859001e0a5f2", null ],
    [ "ifx_vector_copy_r", "ifx_radar___vector_8h.html#a60788d575ba480a8123147f45978cb28", null ],
    [ "ifx_vector_create_c", "ifx_radar___vector_8h.html#a758cd067a3fa1fab7e6134871d5efd0f", null ],
    [ "ifx_vector_create_r", "ifx_radar___vector_8h.html#a548be520d8c6c8d37e2abe43d0adf6c4", null ],
    [ "ifx_vector_destroy_c", "ifx_radar___vector_8h.html#a6bffd531b30623a1a709b51511c95bff", null ],
    [ "ifx_vector_destroy_r", "ifx_radar___vector_8h.html#a60b91857973a08f8827a8e294703f19f", null ],
    [ "ifx_vector_print_c", "ifx_radar___vector_8h.html#a2c1d502c8326fa9385d72ec11e6706b3", null ],
    [ "ifx_vector_print_r", "ifx_radar___vector_8h.html#aa3c939e40de07d02691c4a3a9de9f0f2", null ],
    [ "ifx_vector_rotate_c", "ifx_radar___vector_8h.html#a0fa8a1395486e1e1e910db8886bb724e", null ],
    [ "ifx_vector_rotate_r", "ifx_radar___vector_8h.html#a2acd00759ec6f58ca29cb0329717c83b", null ],
    [ "ifx_vector_set_element_c", "ifx_radar___vector_8h.html#ae7a6529bfb714868dbce7cd855ad5050", null ],
    [ "ifx_vector_set_element_r", "ifx_radar___vector_8h.html#a643a8d68746dc744c5fbc00533db44d6", null ]
];