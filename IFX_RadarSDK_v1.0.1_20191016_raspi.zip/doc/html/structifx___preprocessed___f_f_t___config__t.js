var structifx___preprocessed___f_f_t___config__t =
[
    [ "fft_input_len", "structifx___preprocessed___f_f_t___config__t.html#a30f3b4337cdf6c333cb650599a3eaa63", null ],
    [ "fft_size", "structifx___preprocessed___f_f_t___config__t.html#a01dcb5abf4eaab7937387e6021ba9de6", null ],
    [ "fft_type", "structifx___preprocessed___f_f_t___config__t.html#a5e55069d1b92a17568e7095593121b5b", null ],
    [ "input_sampling_freq_khz", "structifx___preprocessed___f_f_t___config__t.html#af6fe97ce106debf4dc6ca76191f6ea2f", null ],
    [ "is_normalized_window", "structifx___preprocessed___f_f_t___config__t.html#ad213557be7b913986213761ba430b8f8", null ],
    [ "mean_removal_flag", "structifx___preprocessed___f_f_t___config__t.html#af7ab5332bdb95cf668df8536fc423f90", null ],
    [ "window_config", "structifx___preprocessed___f_f_t___config__t.html#abcc2f406697179cb41fec93a0c16d03d", null ]
];