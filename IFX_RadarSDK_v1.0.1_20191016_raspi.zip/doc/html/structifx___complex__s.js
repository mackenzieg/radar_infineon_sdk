var structifx___complex__s =
[
    [ "data", "structifx___complex__s.html#a534748ee20ea51d3201a1d3ef34574d3", null ]
];