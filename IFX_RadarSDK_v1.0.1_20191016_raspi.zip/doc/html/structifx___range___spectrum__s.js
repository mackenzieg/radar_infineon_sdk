var structifx___range___spectrum__s =
[
    [ "fft_mean_result", "structifx___range___spectrum__s.html#a78ec7507941f794beef8daecf7b9f32d", null ],
    [ "fft_result", "structifx___range___spectrum__s.html#aa76583b10e8a34a323ba8b12906bcd56", null ],
    [ "fft_spectrum_matrix", "structifx___range___spectrum__s.html#a5b90f7b0f70dae71cad3d32e210c0222", null ],
    [ "mode", "structifx___range___spectrum__s.html#abd8e1b1119f925d142e8cf95cf6ef34b", null ],
    [ "num_of_chirps", "structifx___range___spectrum__s.html#afa3d99ce5a93a7374619cfec54077314", null ],
    [ "output_scale_type", "structifx___range___spectrum__s.html#ad53006cbbc67c14125c27731f59f98e5", null ],
    [ "preprocessed_fft_handle", "structifx___range___spectrum__s.html#aef21ef203971d5ba1a677a84c7308fac", null ],
    [ "range_axis_spec_m", "structifx___range___spectrum__s.html#ad8f60ebda6dc235eca43961bc3aa37d6", null ],
    [ "single_chirp_mode_index", "structifx___range___spectrum__s.html#add18eaf435ea3ff5326a3de811bc8b9d", null ],
    [ "spect_threshold", "structifx___range___spectrum__s.html#adb93ab255f33613617cad8875e760bc4", null ]
];